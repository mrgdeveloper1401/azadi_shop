from rest_framework.routers import DefaultRouter


app_name = 'payments'
router = DefaultRouter()
urlpatterns = []
