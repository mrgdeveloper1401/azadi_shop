# Kaveh Negar settings
KAVEH_NEGAR_API_KEY = 'your_kaveh_negar_api_key'

