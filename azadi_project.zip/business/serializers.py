# from rest_framework import serializers
# from .models import Top_Students, Top_Teachers, Tajrobi_Top_Levels, Riazi_Top_Levels, Enasani_Top_Levels, Prizes, \
#     Obligations
# from courses.models import Course
#
#
# class TopTeachersSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Top_Teachers
#         fields = '__all__'
#
#
# class TopStudentsSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Top_Students
#         fields = '__all__'
#
#
# class TajrobiTopLevelsSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Tajrobi_Top_Levels
#         fields = '__all__'
#
#
# class RiaziTopLevelsSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Riazi_Top_Levels
#         fields = '__all__'
#
#
# class EnasaniTopLevelsSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Enasani_Top_Levels
#         fields = '__all__'
#
#
# class PrizesSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Prizes
#         fields = '__all__'
#
#
# class ObligationsSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Obligations
#         fields = '__all__'
#
#
# class CoursesSerializers(serializers.ModelSerializer):
#     class Meta:
#         model = Course
#         fields = '__all__'
