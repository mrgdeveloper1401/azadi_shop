from shop.media_sms_config import rest_test_send_sms

rest_test_send_sms()