from random import choices, randint
from string import digits


def generate_random_code():
    return randint(1111, 999999999)
