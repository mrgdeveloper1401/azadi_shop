from django.test import TestCase

# Create your tests here.
from core.web_service_media_sms import rest_test_send_sms

rest_test_send_sms()
