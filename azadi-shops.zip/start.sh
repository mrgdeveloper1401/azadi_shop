#!/bin/sh

0.0.0.0:8000
supervisord
