from string import digits
from random import choices, randint
from django.core.validators import MinValueValidator, MaxValueValidator
from django.db import models
from django.contrib.auth.models import AbstractBaseUser
from django.utils.translation import gettext_lazy as _

from shop.utils import send_sms
from users.managers import UserManager, OtpManager
from users.validators import MobileValidator
from core.models import CreateMixin, UpdateMixin, SoftDeleteMixin
from core.datetime_config import after_two_minute
from django.utils.timezone import now


# Create your models here.
class User(AbstractBaseUser, CreateMixin, UpdateMixin, SoftDeleteMixin):
    mobile_phone = models.CharField(_("شماره همراه"), max_length=11, unique=True,
                                    validators=[MobileValidator()])
    is_verified = models.BooleanField(_('احراز هویت'), default=False)
    is_active = models.BooleanField(
        _("فعال"),
        default=False,
        help_text=_(
            "Designates whether this user should be treated as active. "
            "Unselect this instead of deleting accounts."
        ),
    )
    is_staff = models.BooleanField(
        _("دسترسی کارمندی"),
        default=False,
        help_text=_("Designates whether the user can log into this admin site."),
    )
    USERNAME_FIELD = 'mobile_phone'
    is_superuser = models.BooleanField(
        _("superuser status"),
        default=False,
        help_text=_(
            "Designates that this user has all permissions without "
            "explicitly assigning them."
        ),
    )

    objects = UserManager()

    def has_perm(self, perm, obj=None):
        return True

    def has_module_perms(self, app_label):
        return True

    def deactivate_user(self):
        self.is_active = False
        self.is_verified = False
        self.save()

    def __str__(self):
        return self.mobile_phone

    @property
    def get_user_info_name(self):
        return self.user_info.get_full_name

    class Meta:
        db_table = 'user'
        verbose_name = _("کاربر")
        verbose_name_plural = _("کاربر ها")
        ordering = ('-created_at',)


class Grade(models.Model):
    grade_name = models.CharField(_("نام پایه"), max_length=20)

    def __str__(self):
        return self.grade_name

    class Meta:
        db_table = 'grade'
        verbose_name = _("پایه")
        verbose_name_plural = _("پایه")


class Major(models.Model):
    major_name = models.CharField(_("رشته"), max_length=20, unique=True)

    def __str__(self):
        return self.major_name

    class Meta:
        db_table = 'major'
        verbose_name = _("رشته")
        verbose_name_plural = _("رشته ها")


class UserInfo(CreateMixin, UpdateMixin, SoftDeleteMixin):
    user = models.OneToOneField(User, on_delete=models.PROTECT, related_name='user_info',
                                verbose_name=_("کاربر"))
    # grade = models.ForeignKey(Grade, on_delete=models.PROTECT, related_name='grade',
    #                           verbose_name=_("پایه"), blank=True, null=True)
    # major = models.ForeignKey(Major, on_delete=models.PROTECT, related_name='major',
    #                           verbose_name=_("رشته"), blank=True, null=True)
    # gpa = models.FloatField(_("معدل"), validators=[MinValueValidator(0), MaxValueValidator(20)],
    #                         blank=True, null=True)
    email = models.EmailField(_("ایمیل"), blank=True, null=True)
    first_name = models.CharField(_("نام"), max_length=30, blank=True, null=True)
    last_name = models.CharField(_("نام خوانوادگی"), max_length=30, blank=True, null=True)

    class Meta:
        verbose_name = _("پروفایل کاربر")
        verbose_name_plural = _("پروفایل کاربرها")
        db_table = 'user_info'
        constraints = [
            models.UniqueConstraint(fields=['email'], name='unique_email')
        ]
        ordering = ('-created_at',)

    def __str__(self):
        return self.user.mobile_phone

    @property
    def get_active(self):
        return self.user.is_active

    @property
    def get_is_verified(self):
        return self.user.is_verified

    @property
    def get_full_name(self):
        return f'{self.first_name} {self.last_name}'


class GradeGpa(CreateMixin, UpdateMixin):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='user_grade_gpas',
                             verbose_name=_("کاربر"), limit_choices_to={"is_active": True, "is_verified": True})
    grade = models.ForeignKey(Grade, on_delete=models.PROTECT, related_name='grade_gpa',
                              verbose_name=_("پایه"))
    gpa = models.FloatField(_("معدل"), validators=[MinValueValidator(0), MaxValueValidator(20)])

    class Meta:
        db_table = 'grade_gpa'
        verbose_name = _("نمره کاربر")
        verbose_name_plural = _("نمرات کاربر")
        ordering = ('-created_at',)
        unique_together = ("user", "grade")


class Otp(CreateMixin):
    mobile_phone = models.CharField(_("شماره همراه"), max_length=11, validators=[MobileValidator()])
    code = models.PositiveIntegerField(_('کد'), blank=True, null=True)
    expired_at = models.DateTimeField(_('زمان انتقضای کد'), blank=True, null=True)

    objects = OtpManager()

    def __str__(self):
        return self.mobile_phone

    def is_expired(self):
        return now() > self.expired_at

    def delete_if_expired(self):
        if self.is_expired():
            self.delete()
            return True
        return False

    def save(self, *args, **kwargs):
        self.expired_at = after_two_minute()
        self.code = randint(1, 999999)
        # send_sms(self.mobile_phone, self.code)
        return super().save(*args, **kwargs)

    class Meta:
        db_table = 'otp'
        verbose_name = _('کد otp')
        verbose_name_plural = _('کدهای otp')
        ordering = ('-created_at',)
