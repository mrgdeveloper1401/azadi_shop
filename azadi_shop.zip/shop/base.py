from pathlib import Path
from datetime import timedelta
from decouple import config
import os

from shop.unfold_settings import UNFOLD

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent

# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/4.2/howto/deployment/checklist/

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = config('DEBUG', default=True, cast=bool)

THIRD_PARTY_APPS = [
    'users.apps.UsersConfig',
    'courses.apps.CoursesConfig',
    "images.apps.ImagesConfig",
    'orders.apps.OrdersConfig',
    "professors.apps.ProfessorsConfig",
    'payments.apps.PaymentsConfig',
    "main_settings.apps.MainSettingsConfig",
    "core.apps.CoreConfig",
    "blogs.apps.BlogsConfig",
    # "coupons.apps.CouponsConfig",
]

THIRD_PARTY_PACKAGE = [
    "rest_framework",
    'rest_framework_simplejwt',
    'drf_spectacular',
    # "rest_framework_simplejwt.token_blacklist",
    "treebeard",
    "django_filters",
    # "django_celery_results",
    # "django_celery_beat",
    "storages",
    "corsheaders",
    # 'ckeditor',
    # "ckeditor_uploader",
    "import_export",
    # "jet_django"
]

INSTALLED_APPS = [
    "unfold",
    "unfold.contrib.filters",
    "unfold.contrib.inlines",
    "unfold.contrib.forms",
    "unfold.contrib.import_export",
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    "whitenoise.runserver_nostatic",
    'django.contrib.staticfiles',
    # 'django.contrib.gis',
    *THIRD_PARTY_APPS,
    *THIRD_PARTY_PACKAGE,

]

MIDDLEWARE = [
    # cors middleware
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.security.SecurityMiddleware',
    # whitenoise
    "whitenoise.middleware.WhiteNoiseMiddleware",
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'shop.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'shop.wsgi.application'

# Password validation
# https://docs.djangoproject.com/en/4.2/ref/settings/#auth-password-validators

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
    {
        'NAME': 'shop.uppercase_password_validator.UppercasePasswordValidator',
    }
]

# Internationalization
# https://docs.djangoproject.com/en/4.2/topics/i18n/

LANGUAGE_CODE = 'fa-ir'

TIME_ZONE = 'Asia/Tehran'

USE_I18N = True

USE_TZ = True

USE_L10N = True

# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/4.2/howto/static-files/

STATIC_URL = 'static/'
STATIC_ROOT = os.path.join(BASE_DIR / 'staticfiles')

MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'

# user
AUTH_USER_MODEL = 'users.User'

# spectacular settings
SPECTACULAR_SETTINGS = {
    'TITLE': 'گروه اموزش انرژی',
    'DESCRIPTION': 'Your  description',
    'VERSION': '1.0.0',
    'SERVE_INCLUDE_SCHEMA': False,
    # OTHER SETTINGS
}

# CELERY BEAT SCHEDULER
CELERY_BEAT_SCHEDULER = 'django_celery_beat.schedulers:DatabaseScheduler'

# Django-storages configuration
STORAGES = {
    "default": {
        "BACKEND": "storages.backends.s3.S3Storage",
    },
    'staticfiles': {
        "BACKEND": "whitenoise.storage.CompressedManifestStaticFilesStorage",
        # "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage"
    },
}

# rest framework config
REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'rest_framework_simplejwt.authentication.JWTAuthentication',
    ),
    'DEFAULT_SCHEMA_CLASS': 'drf_spectacular.openapi.AutoSchema',
    # 'DEFAULT_THROTTLE_CLASSES': [
    #     'rest_framework.throttling.AnonRateThrottle',
    #     'rest_framework.throttling.UserRateThrottle'
    # ],
    # 'DEFAULT_THROTTLE_RATES': {
    #     'anon': '10/minute',
    #     'user': '30/minute'
    # }
}

# simple jwt config
SIMPLE_JWT = {
    'ACCESS_TOKEN_LIFETIME': timedelta(days=1),
    'REFRESH_TOKEN_LIFETIME': timedelta(days=1),
    "AUTH_HEADER_TYPES": ('Bearer',),
    "ROTATE_REFRESH_TOKENS": True,
    "BLACKLIST_AFTER_ROTATION": True,
    "UPDATE_LAST_LOGIN": True,
}

# liara config
# S3 Settings
# endpoint_url = config("ARVAN_ENDPOINT", cast=str)
# ARVAN_BUCKET_NAME = config("ARVAN_BUCKET_NAME", cast=str)
# aws_access_key_id = config("ARVAN_ACCESS_KEY", cast=str)
# aws_secret_access_key = config("ARVAN_SECRET_KEY", cast=str)

# S3 Settings Based on AWS (optional)
AWS_ACCESS_KEY_ID = config("ARVAN_ACCESS_KEY", cast=str)
AWS_SECRET_ACCESS_KEY = config("ARVAN_SECRET_KEY", cast=str)
AWS_STORAGE_BUCKET_NAME = config('ARVAN_BUCKET_NAME', cast=str)
AWS_S3_ENDPOINT_URL = config("ARVAN_ENDPOINT", cast=str)
AWS_S3_REGION_NAME = 'us-east-1'
AWS_S3_FILE_OVERWRITE = False
AWS_SERVICE_NAME = 's3'
# AWS_QUERYSTRING_AUTH = False
# AWS_S3_VERIFY = False
# for upload object storage
AWS_S3_SECURE_URLS = True

# ckeditor
# CKEDITOR_CONFIGS = {
#     'default': {
#         'toolbar': 'full',
#         'removePlugins': "exportpdf",
#     },
# }

CKEDITOR_ALLOW_ALL_FILE_TYPES = True
CKEDITOR_MAX_FILE_SIZE = 5
CKEDITOR_FILE_UPLOAD_PERMISSION = "staff"
CKEDITOR_UPLOAD_PATH = "uploads/"
CKEDITOR_RESTRICT_BY_USER = True
CKEDITOR_IMAGE_BACKEND = "pillow"
CKEDITOR_STORAGE_BACKEND = STORAGES['default']['BACKEND']
# CKEDITOR_BASEPATH = os.path.join(BASE_DIR, 'static', 'ckeditor')
CKEDITOR_BROWSE_SHOW_DIRS = True
# CKEDITOR_RESTRICT_BY_DATE = True
CKEDITOR_THUMBNAIL_SIZE = (100, 100)
CKEDITOR_IMAGE_QUALITY = 100

# django admin chart config
# ADMIN_CHARTS_NVD3_JS_PATH = 'bow/nvd3/build/nv.d3.js'
# ADMIN_CHARTS_NVD3_CSS_PATH = 'bow/nvd3/build/nv.d3.css'
# ADMIN_CHARTS_D3_JS_PATH = 'bow/d3/d3.js'
# BOWER_COMPONENTS_ROOT = os.path.join(BASE_DIR, 'components')
# BOWER_INSTALLED_APPS = [
#     'd3#3.3.13',
#     'nvd3#1.7.1',
# ]
#
# STATICFILES_FINDERS = [
#     'djangobower.finders.BowerFinder',
# ]


# jet admin token
# JET_PROJECT = 'raminazadi_shop'
# JET_TOKEN = config("JET_TOKEN", cast=str)
