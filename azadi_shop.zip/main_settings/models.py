from django.core.exceptions import ValidationError
from django.db import models
from django.utils.translation import gettext_lazy as _

from core.models import CreateMixin, UpdateMixin
from main_settings.validators import HomeMobileValidator
from users.validators import MobileValidator


# Create your models here.
class HeaderSite(CreateMixin, UpdateMixin):
    title = models.CharField(_("title"), max_length=50)
    is_active = models.BooleanField(_("is active"), default=True)

    def __str__(self):
        return self.title

    class Meta:
        db_table = 'header_site'
        verbose_name = _("هدر سایت")
        verbose_name_plural = _("هدر سایت")


class HomeSite(CreateMixin, UpdateMixin):
    site_logo = models.ImageField(_('عکس لوگو سایت'), upload_to='main_settings/home-site/%Y/%m/%d')
    slider_image = models.ManyToManyField("images.Image", related_name='home_site_slider',
                                          verbose_name=_("عکس اسلایدر سایت"))
    header_phone_number = models.CharField(_("شماره تماس هدر"), max_length=15, unique=True,
                                           validators=[HomeMobileValidator()],
                                           help_text=_("شماره تماس میتواند 11 رقمی تا 15 رقمی باشد"))
    about_us_body = models.TextField(_("متن درباره ما"))
    slider_professor_image = models.ManyToManyField('images.Image', related_name='home_site_slider_professor_image',
                                                    verbose_name=_("عکس اساتید"))
    email = models.EmailField(_("ایمیل"), unique=True)
    description_footer = models.TextField(_("توضیح فوتر"))
    awards_image = models.ManyToManyField('images.Image', related_name='home_site_awards_image',
                                          verbose_name=_('عکس جوایز و افتخارات'))
    team_image = models.ManyToManyField('images.Image', related_name='home_site_team_image',
                                        verbose_name=_("عکس تیم"))
    is_active = models.BooleanField(_("فعال باشد"), default=True)

    def __str__(self):
        return f"{self.header_phone_number} {self.email} {self.is_active}"

    def clean(self):
        if self.is_active:
            if HomeSite.objects.filter(is_active=True).exists():
                raise ValidationError({"is_active": _("شما فقط میتواند یک تنطم سایت فعال رو داشته باشد")})
        return super().clean()

    class Meta:
        db_table = 'home_site'
        verbose_name = _("بخش هایی از سایت")
        verbose_name_plural = _("بخش های از سایت")


class ContactUs(CreateMixin, UpdateMixin):
    full_name = models.CharField(_("نام و نام خوانوادگی"), max_length=150)
    mobile_phone = models.CharField(_("شماره موبایل"), max_length=11, validators=[MobileValidator()])
    description = models.TextField(_("توضیح"))

    def __str__(self):
        return f'{self.full_name} {self.mobile_phone}'

    class Meta:
        db_table = 'contact_us'
        verbose_name = _("تماس با ما")
        verbose_name_plural = _("تماس با ما")


class TopRankProfessor(CreateMixin, UpdateMixin):
    full_name = models.CharField(_("نام و نام خوانوادگی"), max_length=50)
    field_title = models.CharField(_("عنوان درس"), max_length=50)
    professor_image = models.ImageField(_("عکس اساتید"), upload_to='main_settings/top_professor/%Y/%m/%d')

    def __str__(self):
        return f"{self.full_name} {self.field_title}"

    class Meta:
        db_table = 'top_rank_professo r'
        verbose_name = _("برترین اساتید")
        verbose_name_plural = _("برترین اساتید")


class TopRankStudent(CreateMixin, UpdateMixin):
    # slug = models.SlugField(_("slug"), unique=True, allow_unicode=True)
    first_name = models.CharField(_("نام"), max_length=150)
    last_name = models.CharField(_("نام خوانوادگی"), max_length=150)
    fields = models.CharField(_("عنوان شغلی"), max_length=50)
    is_active = models.BooleanField(_("فعال بودن"), default=True)

    class TitleChoices(models.TextChoices):
        experimental = 'experimental', _("تجربی")
        math = 'math', _("ریاضی")
        human = 'human', _("انسانی")

    title = models.CharField(_("رشته تحصیلی"), max_length=12, choices=TitleChoices.choices)

    def __str__(self):
        return f"{self.title} {self.first_name} {self.last_name}"

    class Meta:
        db_table = 'top_rank'
        verbose_name = _("برترین دانشجویان")
        verbose_name_plural = _("برترین دانشجویان")


class Newsletter(CreateMixin, UpdateMixin):
    email = models.EmailField(_("email"))

    def __str__(self):
        return self.email

    class Meta:
        db_table = 'newsletter'
        verbose_name = _("خبرنامه")
        verbose_name_plural = _("خبرنامه")


class BusinessAddress(CreateMixin, UpdateMixin):
    address = models.TextField(_("ادرس"))
    location_lat = models.DecimalField(max_digits=20, decimal_places=10)
    location_long = models.DecimalField(max_digits=20, decimal_places=10)
    is_active = models.BooleanField(_("فعال بودن"), default=True)

    def __str__(self):
        return f'{self.location_lat} {self.location_long}'

    class Meta:
        db_table = 'business_address'
        verbose_name = _("ادرس شعب")
        verbose_name_plural = _("ادرس شعب ها")
